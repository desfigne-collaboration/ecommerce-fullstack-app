import React from 'react';
import { Counter } from './components/counter/Counter.jsx';

export default function AppCounter() {
    return (
        <div>
            <Counter />
        </div>
    );
}

